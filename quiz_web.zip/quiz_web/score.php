<?php
session_start();
?>
<html>
<head>
<title>score_dashbord</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="nav">
               <h1>scoreboard</h1>
		   <ul>
		       <li><a href="question_panel.php">retry</a></li>
			   <li><a href="index.php">back</a></li>
		   </ul>
			</div>		   
<div class="score" style="color:white;background-color:green;padding:10px;width:300px;margin-left:500px;margin-top:100px;text-align:center;text-transform:uppercase">
		   <?php
echo "<h2>your performance</h2>";
if($_SESSION['score'] == 1)
           {echo "<h2>Poor</h2>";}
      else if($_SESSION['score'] == 2)
	       {echo "<h2>Bad</h2>";}
	  else if($_SESSION['score'] == 3)
	       {echo "<h2>Good</h2>";}
	  else if($_SESSION['score'] == 4)
	       {echo "<h2>Strong</h2>";}
	  else if($_SESSION['score'] == 5)
	       {echo "<h2>Very Strong</h2>";}
	  else {echo "<h2>all incorrect you have to work hard</h2>";}
	  echo "<h2>correct = ".$_SESSION['score']."</h2>";
	  echo "<h2>incorrect = ".(5-$_SESSION['score'])."</h2>";
?>
</div>
</body>
</html>