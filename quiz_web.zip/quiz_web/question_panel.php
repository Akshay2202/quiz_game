<?php
session_start();
?>
<html>
      <head>
	       <title>question_panel</title>
	       <link href="style.css" rel="stylesheet" type="text/css">
		   <script type="text/javascript">
		   function timeout()
		   {
			   var minute=Math.floor(timeLeft/60);
			   var second=timeLeft%60;
			   if(timeLeft<=0)
			   {
				   clearTimeout(tm);
				   document.getElementById("form").submit();
			   }
			   else
			   {
				 document.getElementById("time").innerHTML=minute+":"+second;
			   }
			   timeLeft--;
			   var tm= setTimeout(function(){timeout()},1000);
		   }
		   </script>
	  </head>
	  <body onload="timeout()">
	  <div class="about">
		   <h2><a href="index.php">back</a></h2>
		   </div>
		   <script type="text/javascript">
		   var timeLeft=30;
		   </script>
		<div id="time" style="color:red"><h2>timeout</h2></div>   
	  <div class="quest">
		   <?php
		    $count=0;
			$level=$_SESSION['level'];
		    $h=fopen("question.txt","r");
			if($level == 1)
			{
				?><h1>easy</h1><?php
			}
			else if($level == 2)
			{
				?><h1>medium</h1><?php
			}
			else if($level == 3)
			{
				?><h1>hard</h1><?php 
			}
			?><form method="post" id="form"><?php
            while($l=fgets($h))
            {
				$count++;
			   if($count < 31 && $level == 1)
				{					
				echo $l."<br />";
				
				if($count == 6)
				{
					?>
					(a)<input type="radio" value="a" name="que">
					(b)<input type="radio" value="b" name="que">
					(c)<input type="radio" value="c" name="que">
					(d)<input type="radio" value="d" name="que">	</br>			
					<?php
				}
				else if($count == 12)
				{
					?>
					(a)<input type="radio" value="a" name="que2">
					(b)<input type="radio" value="b" name="que2">
					(c)<input type="radio" value="c" name="que2">
					(d)<input type="radio" value="d" name="que2">	</br>			
					<?php
				}
				else if($count == 18)
				{
					?>
					(a)<input type="radio" value="a" name="que3">
					(b)<input type="radio" value="b" name="que3">
					(c)<input type="radio" value="c" name="que3">
					(d)<input type="radio" value="d" name="que3">	</br>			
					<?php
				}
				else if($count == 24)
				{
					?>
					(a)<input type="radio" value="a" name="que4">
					(b)<input type="radio" value="b" name="que4">
					(c)<input type="radio" value="c" name="que4">
					(d)<input type="radio" value="d" name="que4">	</br>			
					<?php
				}
				else if($count == 30)
				{
					?>
					(a)<input type="radio" value="a" name="que5">
					(b)<input type="radio" value="b" name="que5">
					(c)<input type="radio" value="c" name="que5">
					(d)<input type="radio" value="d" name="que5">	</br>			
					<?php
				}
				
				if($count == 30)
				{
					break;
				}
			    } 
				if($count < 61 && $level == 2 && $count > 30)
				{	
				echo $l."<br />";
				
				if($count == 36)
				{
					?> 
					(a)<input type="radio" value="a" name="que">
					(b)<input type="radio" value="b" name="que">
					(c)<input type="radio" value="c" name="que">
					(d)<input type="radio" value="d" name="que">	</br>			
					<?php
				}
				else if($count == 42)
				{
					?>
					(a)<input type="radio" value="a" name="que2">
					(b)<input type="radio" value="b" name="que2">
					(c)<input type="radio" value="c" name="que2">
					(d)<input type="radio" value="d" name="que2">	</br>			
					<?php
				}
				else if($count == 48)
				{
					?>
					(a)<input type="radio" value="a" name="que3">
					(b)<input type="radio" value="b" name="que3">
					(c)<input type="radio" value="c" name="que3">
					(d)<input type="radio" value="d" name="que3">	</br>			
					<?php
				}
				else if($count == 54)
				{
					?>
					(a)<input type="radio" value="a" name="que4">
					(b)<input type="radio" value="b" name="que4">
					(c)<input type="radio" value="c" name="que4">
					(d)<input type="radio" value="d" name="que4">	</br>			
					<?php
				}
				else if($count == 60)
				{
					?>
					(a)<input type="radio" value="a" name="que5">
					(b)<input type="radio" value="b" name="que5">
					(c)<input type="radio" value="c" name="que5">
					(d)<input type="radio" value="d" name="que5">	</br>			
					<?php
				}
				
				
				if($count == 60)
				{
					break;
				}
                }
				if($count < 91 && $level == 3 && $count > 60)
				{	
				echo $l."<br />";
				
				if($count == 66)
				{
					?>
					(a)<input type="radio" value="a" name="que">
					(b)<input type="radio" value="b" name="que">
					(c)<input type="radio" value="c" name="que">
					(d)<input type="radio" value="d" name="que">	</br>			
					<?php
				}
				else if($count == 72)
				{
					?>
					(a)<input type="radio" value="a" name="que2">
					(b)<input type="radio" value="b" name="que2">
					(c)<input type="radio" value="c" name="que2">
					(d)<input type="radio" value="d" name="que2">	</br>			
					<?php
				}
				else if($count == 78)
				{
					?>
					(a)<input type="radio" value="a" name="que3">
					(b)<input type="radio" value="b" name="que3">
					(c)<input type="radio" value="c" name="que3">
					(d)<input type="radio" value="d" name="que3">	</br>			
					<?php
				}
				else if($count == 84)
				{
					?>
					(a)<input type="radio" value="a" name="que4">
					(b)<input type="radio" value="b" name="que4">
					(c)<input type="radio" value="c" name="que4">
					(d)<input type="radio" value="d" name="que4">	</br>			
					<?php
				}
				else if($count == 89)
				{
					?>
					(a)<input type="radio" value="a" name="que5">
					(b)<input type="radio" value="b" name="que5">
					(c)<input type="radio" value="c" name="que5">
					(d)<input type="radio" value="d" name="que5">	</br>			
					<?php
				}
				
				
				if($count == 90)
				{
					break;
				}
			    }
                				
			}				
			fclose($h);
		   
		   ?>
					<input type="submit" name="submit" value="SUBMIT">
		   </form>
		</div>  
<?php

  if(isset($_POST['submit']))
  {
	  $correct=0;
	  $con=mysqli_connect('localhost','root','','quiz_web');
if($level == 1)	
{
	$qno=1;
	 while($qno < 6)
	  {
		  if($qno == 1 && isset($_POST['que']))
		  {
			  $answer = $_POST['que'];
		  }
		  else if($qno == 2 && isset($_POST['que2']))
		  {
			  $answer = $_POST['que2'];
		  }
		  else if($qno == 3 && isset($_POST['que3']))
		  {
			  $answer = $_POST['que3'];
		  }
		  else if($qno == 4 && isset($_POST['que4']))
		  {
			  $answer = $_POST['que4'];
		  }
		  else if($qno == 5 && isset($_POST['que5']))
		  {
			  $answer = $_POST['que5'];
		  }
          else
          {
			  $answer = "z";
		  }			  
	 
	   $query="SELECT * FROM answers WHERE qno='$qno' AND answer='$answer'";
	  $run=mysqli_query($con,$query);	
	  if(mysqli_num_rows($run)>0)
	  {
		  $correct++;
	  }
	  $qno++;
	  }
}
	  if($level == 2)
	  {
		  $qno=6; 
	   while($qno < 11)
	  {
		  if($qno == 6 && isset($_POST['que']))
		  {
			  $answer = $_POST['que'];
		  }
		  else if($qno == 7 && isset($_POST['que2']))
		  {
			  $answer = $_POST['que2'];
		  }
		  else if($qno == 8 && isset($_POST['que3']))
		  {
			  $answer = $_POST['que3'];
		  }
		  else if($qno == 9 && isset($_POST['que4']))
		  {
			  $answer = $_POST['que4'];
		  }
		  else if($qno == 10 && isset($_POST['que5']))
		  {
			  $answer = $_POST['que5'];
		  }
		  else
          {
			  $answer = "z";
		  }	
	  
	 
	   $query="SELECT * FROM answers WHERE qno='$qno' AND answer='$answer'";
	  $run=mysqli_query($con,$query);	
	  if(mysqli_num_rows($run)>0)
	  {
		  $correct++;
	  }
	  $qno++;
	  }
  }
  
  if($level == 3)	
{
	$qno=11;
	 while($qno < 16)
	  {
		  if($qno == 11 && isset($_POST['que']))
		  {
			  $answer = $_POST['que'];
		  }
		  else if($qno == 12 && isset($_POST['que2']))
		  {
			  $answer = $_POST['que2'];
		  }
		  else if($qno == 13 && isset($_POST['que3']))
		  {
			  $answer = $_POST['que3'];
		  }
		  else if($qno == 14 && isset($_POST['que4']))
		  {
			  $answer = $_POST['que4'];
		  }
		  else if($qno == 15 && isset($_POST['que5']))
		  {
			  $answer = $_POST['que5'];
		  }
		  else
          {
			  $answer = "z";
		  }	
	  
	 
	   $query="SELECT * FROM answers WHERE qno='$qno' AND answer='$answer'";
	  $run=mysqli_query($con,$query);	
	  if(mysqli_num_rows($run)>0)
	  {
		  $correct++;
	  }
	  $qno++;
	  }
}   

$_SESSION['score'] = $correct; 
	  ?><script>
	  alert('final submit');
	  </script><?php
header('location:score.php'); 
 }

?>		

	  </body>
</html>