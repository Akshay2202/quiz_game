<?php
session_start();
?>
<html>
      <head>
	        <title>Quiz Game</title>
			<link href="style.css" rel="stylesheet" type="text/css">
	  </head>
	  <body>
	        <div class="nav">
			     <h1>quiz game</h1>
		   <ul>
		       <li><a href="about.php">rules</a></li>
			   <li><a href="about.php">about</a></li>
		   </ul>
			</div>
			<section>
	                 <div class="left">
	                     <img src="quizlogo.png">	
                     </div>
                     <div class="right">							 
						<form method="post">
                            
							<input type="submit" name="easy" value="EASY">
                            <input type="submit" name="medium" value="MEDIUM">
                            <input type="submit" name="hard" value="HARD">	
                            							
                        </form>
	                 </div>
	        </section>
			
<?php
if(isset($_POST['easy']))
{
	$_SESSION['level']= 1;
   header('location:question_panel.php');
}
else if(isset($_POST['medium']))
{
	$_SESSION['level']= 2;
   header('location:question_panel.php');
}
else if(isset($_POST['hard']))
{
	$_SESSION['level']= 3;
   header('location:question_panel.php');
}
?>			
	  </body>
</html>
